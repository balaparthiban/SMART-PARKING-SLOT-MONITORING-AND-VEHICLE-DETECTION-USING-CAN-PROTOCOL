#include <LPC21xx.h>

void delay_ms(unsigned int ms)
{
    T0PR = 15000 - 1;
    T0TCR =0x01;
    while(T0TC < ms);
    T0TCR =0x03;
	T0TCR=0x00;
}

int main()
{
	int flag=0;
    int x = (1000 * 15) - 1;       // 0�
	PINSEL1 = 1 << 10;             // P0.21 -> PWM5
	PWMMR0 = (20000 * 15) - 1;     // 20 ms period
    PWMMR5 = x;
	PWMMCR = 2;
    PWMPCR = 1 << 13;
    PWMTCR = 0x09;
    PWMLER = (1<<0) | (1<<5);

    while(1)
    {
        PWMMR5 = x;
        PWMLER = 1 << 5;
	   	delay_ms(100);

        x = x + (56 * 15);         // Increase by 10�

		if(flag)
		break;
        if(x > ((2200 * 15) - 1))  // Greater than 90�
        {
            x = (1000 * 15) - 1;   // Reset to 0�
			flag=1;
		
        }

    }
}
